//
//  ViewController.m
//  Block_Group
//
//  Created by Oleksandr Davydiuk on 09.02.2021.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSFileManager *fileManager;
    NSOperation *queue;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:@"/Users/odavydi/textfilenew.txt"])
    {
        NSString *filePath = @"/Users/odavydi/textfilenew.txt";
        NSString *readFile = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
        unsigned long count = readFile.length;
        
        NSString *string1 = [readFile substringToIndex:(readFile.length - (readFile.length / 2))];
        NSString *string2 = [readFile substringFromIndex:count / 2];;
        
        queue = [NSOperation new];
        
        const char *char1 = [string1 cStringUsingEncoding:[NSString defaultCStringEncoding]];
        const char *char2 = [string2 cStringUsingEncoding:[NSString defaultCStringEncoding]];
        
        
        __block int count1 = 0;
        __block int count2 = 0;
        
        unsigned long length1 = string1.length;
        unsigned long length2 = string2.length;
        
        dispatch_group_t group = dispatch_group_create();

        dispatch_group_async(group,dispatch_get_main_queue(), ^ {
            for (int i = 0; i < length1; i++)
            {
                if (char1[i] == 'A') count1++;
            }
        });

        dispatch_group_async(group,dispatch_get_main_queue(), ^ {
            for (int i = 0; i < length2; i++)
            {
                if (char2[i] == 'A') count2++;
            }
        });

        dispatch_group_notify(group,dispatch_get_main_queue(), ^ {
            NSLog(@"%d", count1 + count2);
        });
    }
    
}

@end
