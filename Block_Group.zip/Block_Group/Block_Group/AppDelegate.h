//
//  AppDelegate.h
//  Block_Group
//
//  Created by Oleksandr Davydiuk on 09.02.2021.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

