//
//  SceneDelegate.h
//  Block_Group
//
//  Created by Oleksandr Davydiuk on 09.02.2021.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

